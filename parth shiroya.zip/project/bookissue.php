<?php
$conn = mysqli_connect("localhost","parth","","library");
if (!$conn) {
	die("connecation Failed");
}




?>