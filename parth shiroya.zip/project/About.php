<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
	<link rel="stylesheet" type="text/css" href="aboutcssfile.css">
</head>
<body>
<form action="#" method="POST">
	<form class="container-fluid justify-content-start">
    <button class="btn btn-outline-success me-2" type="button"><a  href="HomePage.php"><img src="back.jfif" height="35px" width="35px"></a></button>
  </form>
	<center><h1>About Us</h1></center><hr>
	<br><br>
	<div id="c">

	<h2><b>Web Page Details</b></h2><br>
	<li style="font-size: 25px">
		This Web Page are created using this langauage...
	</li>
	<ol style="font-size: 20px">
	<li style="color: red">HTML</li><br>
	<li style="color: cyan">CSS</li><br>
	<li style="color: orange">Java Sacript</li><br>
	<li style="color: blue">Jquery</li><br>
	<li style="color: green">PHP</li>
	</ol><br><br>
	<h2><b>Purpose of our Website</b></h2>
	<ul style="list-style-type: circle-bold; font-size: 20px">
		<li>Easy To use</li><br>
		<li>Buy online book</li><br>
		<li>Easy To understood</li><br>
		<li>Read a book and also Download the book</li><br>
		<li>Issue book</li><br>
		<li>Return book</li>
	</ul><br><hr>
	<div>
		<h2>Web Page Devloped</h2>
		
		<img src="A1.jpeg" id="p">
		<h3 >
			Name:    Parth Shiroya<br><br>
			Email:    parth17@gmail.com<br><br>
			Contact No:    7096900982
		</h3>

	</div></div>

	<div id="right"></div>
	
	

		

</form>
</body>
</html>