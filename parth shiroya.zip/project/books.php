<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<title>Books Details</title>
<style type="text/css">
	.abc{
		pointer-events: none;
	}
</style>
  </head>
  <body style="background-color: cyan">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
    <form class="container-fluid justify-content-start">
    <button class="btn btn-outline-success me-2" type="button"><a  href="bookstore.php"><img src="back.jfif" height="35px" width="35px"></a></button>
  </form>
    <center><h1>Books are Available</h1></center>
    <br><br>
    <h3 style="text-shadow: 4px 3px 4px pink">COMPUTER ENGINEERING</h3>
 <div class="card-group">
    <div class="card">
    <div class="card-body">
      
      <embed src=".Net.png" width="200px" height="200px" />
   	<br>
   	<p class="abc"><b>.Net Technology</b></p>
   	<a href=".Net.pdf" download=".Net.pdf"><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>


  <div class="card">
    <div class="card-body">
      <embed src="CD.png" width="200px" height="200px" />
   	<br>
   	<p><b>Computer Design</b></p>
   	<a href="" download=".Net.pdf"><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      
      <embed src="wt.png" width="200px" height="200px" />
   	<br>
   	<p><b>Web Technology</b></p>
   	<a href="" download=".Net.pdf"><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>
</div>
<br><br>
<hr>

<h3 style="color: black"><b>Civil ENGINEERING</b></h3>
 <div class="card-group">
    <div class="card">
    <div class="card-body">
      
      <embed src="c1.png" width="200px" height="200px" />
    <br>
    <p class="abc"><b>Engineering Drawing</b></p>
    <a href=".Net.pdf" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>


  <div class="card">
    <div class="card-body">
      <embed src="c2.png" width="200px" height="200px" />
    <br>
    <p><b>Vector Mechanics for Engineers</b></p>
    <a href="" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>


  <div class="card">
    <div class="card-body">
      
      <embed src="c3.png" width="200px" height="200px" />
    <br>
    <p><b>Construction Mathematics</b></p>
    <a href="" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>
</div>
<br><br>
<h3 style="color: red"><b>Mechanical ENGINEERING</b></h3>
 <div class="card-group">
    <div class="card">
    <div class="card-body">
      
      <embed src="m1.png" width="200px" height="200px" />
    <br>
    <p class="abc"><b>Maths</b></p>
    <a href=".Net.pdf" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>


  <div class="card">
    <div class="card-body">
      <embed src="m2.png" width="200px" height="200px" />
    <br>
    <p><b>Autocade</b></p>
    <a href="" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>


  <div class="card">
    <div class="card-body">
      
      <embed src="m3.png" width="200px" height="200px" />
    <br>
    <p><b>Design Of Machine Elements</b></p>
    <a href="" download=""><br>
  <button style="color: red ">Download</button><br>  
    </div>
  </div>
</div>


  </body>
</html>


