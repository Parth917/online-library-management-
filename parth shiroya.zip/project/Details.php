
<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Details</title>
  </head>
  <body>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
    <form class="container-fluid justify-content-start">
    <button class="btn btn-outline-success me-2" type="button"><a  href="HomePage.php"><img src="back.jfif" height="35px" width="35px"></a></button>
  </form>
   <center> <h1>Detais About our Web Page</h1></center><hr>
    <div class="d-grid gap-2 col-6 mx-auto">
  <button class="btn btn-primary" type="button"><a href="User.php" style="color:red">User Details</a></button><br><br>
  <button class="btn btn-primary" type="button"><a href="is_re.php" style="color:cyan">Issued Details</a></button><br><br>
  <button class="btn btn-primary" type="button"><a href="Rdetails.php" style="color:black">Return Details</a></button>
</div>
  </body>
</html>