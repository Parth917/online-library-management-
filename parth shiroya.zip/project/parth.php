<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<style>
	#a{
		background-image: url(index1.jfif);
		background-repeat: no-repeat;
		background-size: cover;
		
		}
		#b{
			font-size: 25px;
		}
</style>
    <title>Main Page</title>
  </head>
  
  <body id="a">
    <h1><center>WELCOME</center></h1>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Hello guys!</strong> You can use this website fisrt of you have to do Register/login..! 
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
         <b> <a class="nav-link active" aria-current="page" href="registerpage.php" id="b">Register</a></b>
        </li>
        <li class="nav-item">
          <b><a class="nav-link active" href="Login page.php" id="b">Login</a></b>
        </li>
        
  </body>
</html>
</body>
</html>